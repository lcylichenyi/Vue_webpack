// 项目的JS入口文件
console.log('ok')

import Vue from 'vue'
import app from './App.vue'

var vm = new Vue({
	el: '#app',
	render: c => c(app)
})
