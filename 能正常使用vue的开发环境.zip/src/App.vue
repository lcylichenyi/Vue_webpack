<template>
	<div>
		这是app.vue
	</div>
</template>

<script>
</script>

<style scoped lang="less">
</style>